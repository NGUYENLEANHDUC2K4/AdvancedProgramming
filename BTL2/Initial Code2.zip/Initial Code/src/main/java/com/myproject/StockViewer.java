package com.myproject;

public interface StockViewer {
    void onUpdate(StockPrice stockPrice);
}
